// public/ubicaciones.js
const API = '/api/ubicaciones';
const tbody = document.getElementById('tbody');
const btnNueva = document.getElementById('btnNueva'); // Ojo: en tu HTML es btnNueva (femenino)
const modal = new bootstrap.Modal(document.getElementById('modal'));
const $ = (id) => document.getElementById(id);

// Verificación de rol (Solo admin suele editar ubicaciones, ajusta si necesitas más roles)
const isAdmin = window.CURRENT_USER_ROLE === 'admin';

// --- HELPERS ---

function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  const bg = type === 'success' ? 'bg-success' : type === 'error' ? 'bg-danger' : 'bg-info';
  const el = document.createElement('div');
  el.className = `toast align-items-center text-white ${bg} border-0`;
  el.role = 'alert'; el.ariaLive = 'assertive'; el.ariaAtomic = 'true';
  el.innerHTML = `<div class="d-flex"><div class="toast-body">${message}</div>
    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>`;
  container.appendChild(el);
  const t = new bootstrap.Toast(el, { delay: 2800 }); t.show();
  el.addEventListener('hidden.bs.toast', () => el.remove());
}

async function fetchJSON(url, opts) {
  const r = await fetch(url, opts);
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}

// --- FUNCIÓN PRINCIPAL: LISTAR ---

async function listar() {
  // 1. Obtener datos
  let data = [];
  try {
    data = await fetchJSON(API);
  } catch (error) {
    console.error(error);
    tbody.innerHTML = '<tr><td colspan="9" class="text-center text-danger">Error de conexión</td></tr>';
    return;
  }

  // 2. Capturar valores de filtros
  // Usamos ?.value por seguridad, aunque si el HTML es fijo siempre existirán
  const q = $('q')?.value.toLowerCase().trim() || '';
  const fSede = $('fSede')?.value.toLowerCase().trim() || '';
  const fEdificio = $('fEdificio')?.value.toLowerCase().trim() || '';
  const fPiso = $('fPiso')?.value.trim() || ''; // Select: búsqueda exacta (o vacío)
  const fSala = $('fSala')?.value.toLowerCase().trim() || '';

  // 3. Filtrar en memoria
  const filtrados = data.filter(u => {
    // Preparar valores del objeto (handling nulls)
    const id = String(u.id);
    const ident = (u.identificacion || '').toLowerCase();
    const sede = (u.sede || '').toLowerCase();
    const edif = (u.edificio || '').toLowerCase();
    const sala = (u.sala || '').toLowerCase();
    const piso = String(u.piso || '');

    // Lógica de filtrado
    const matchQ = !q || id.includes(q) || ident.includes(q);
    const matchSede = !fSede || sede.includes(fSede);
    const matchEdif = !fEdificio || edif.includes(fEdificio);
    const matchPiso = !fPiso || piso === fPiso; // Comparación exacta para el select
    const matchSala = !fSala || sala.includes(fSala);

    return matchQ && matchSede && matchEdif && matchPiso && matchSala;
  });

  // 4. Renderizar
  tbody.innerHTML = '';
  if (!filtrados.length) {
    tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted py-4">Sin resultados</td></tr>';
    return;
  }

  filtrados.forEach(u => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${u.id}</td>
      <td class="fw-semibold">${u.identificacion || ''}</td>
      <td>${u.sede || ''}</td>
      <td>${u.edificio || ''}</td>
      <td>${u.piso || ''}</td>
      <td>${u.sala || ''}</td>
      <td>${u.createdAt || ''} </td>
      <td>${u.updatedAt || ''} </td>
      <td class="col-acciones">
        ${
          isAdmin 
          ? `
            <button class="btn btn-warning btn-compact me-1" data-act="edit" data-id="${u.id}">Editar</button>
            <button class="btn btn-danger btn-compact" data-act="del" data-id="${u.id}">Eliminar</button>
            `
          : `<span class="text-muted small">Solo lectura</span>`
        }
      </td>`;
    tbody.appendChild(tr);
  });
}

// --- EVENT LISTENERS ---

// Filtros: Botón Filtrar
document.getElementById('btnFiltrar')?.addEventListener('click', () => {
  listar().catch(() => showToast('Error al filtrar', 'error'));
});

// Filtros: Botón Limpiar
document.getElementById('btnLimpiar')?.addEventListener('click', () => {
  // Limpiamos todos los inputs definidos en tu HTML
  if ($('q')) $('q').value = '';
  if ($('fSede')) $('fSede').value = '';
  if ($('fEdificio')) $('fEdificio').value = '';
  if ($('fPiso')) $('fPiso').value = ''; // Vuelve al <option value="">Todos</option>
  if ($('fSala')) $('fSala').value = '';
  
  listar().catch(() => showToast('Error al limpiar', 'error'));
});

// Botón Nueva Ubicación
btnNueva?.addEventListener('click', () => {
  $('title').textContent = 'Nueva ubicación';
  // Limpiar campos del formulario
  $('id').value = '';
  $('identificacion').value = '';
  $('sede').value = '';
  $('edificio').value = '';
  $('piso').value = '';
  $('sala').value = '';
  modal.show();
});

// Acciones en Tabla (Delegación)
tbody.addEventListener('click', async (e) => {
  if (!isAdmin) return; // Protección frontend extra

  const btn = e.target.closest('button');
  if (!btn) return;
  const { act, id } = btn.dataset;

  if (act === 'edit') {
    try {
      const items = await fetchJSON(API);
      const u = items.find(x => x.id == id);
      if (!u) return showToast('No encontrado', 'error');

      $('title').textContent = `Editar ubicación #${id}`;
      $('id').value = id;
      $('identificacion').value = u.identificacion;
      $('sede').value = u.sede;
      $('edificio').value = u.edificio;
      $('piso').value = u.piso;
      $('sala').value = u.sala;
      modal.show();
    } catch (err) {
      showToast('Error al cargar datos', 'error');
    }
  } else if (act === 'del') {
    if (!confirm('¿Eliminar ubicación?')) return;
    try {
      await fetchJSON(`${API}/${id}`, { method: 'DELETE' });
      await listar();
      showToast('Ubicación eliminada', 'info');
    } catch (e) {
      showToast('No se pudo eliminar (quizá tiene equipos asignados)', 'error');
    }
  }
});

// Guardar (Submit del formulario)
document.getElementById('form')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  
  if (!isAdmin) {
    showToast('No tiene permisos para modificar ubicaciones', 'error');
    return;
  }

  const payload = {
    identificacion: $('identificacion').value.trim(),
    sede: $('sede').value.trim(),
    edificio: $('edificio').value.trim(),
    piso: $('piso').value.trim(),
    sala: $('sala').value.trim()
  };

  const id = $('id').value;

  try {
    const opts = { headers: { 'Content-Type': 'application/json' } };
    if (id) {
      await fetchJSON(`${API}/${id}`, { method: 'PUT', ...opts, body: JSON.stringify(payload) });
    } else {
      await fetchJSON(API, { method: 'POST', ...opts, body: JSON.stringify(payload) });
    }
    modal.hide();
    await listar();
    showToast(id ? 'Ubicación actualizada' : 'Ubicación creada');
  } catch (e) {
    showToast('Error al guardar', 'error');
  }
});

// Inicialización
listar().catch(() => showToast('Error al iniciar', 'error'));