// public/personas_mantenimiento.js
const API = '/api/personas-mantenimiento';
const API_CARGOS = '/api/cargos';

const tbody = document.getElementById('tbody');
const btnNuevo = document.getElementById('btnNuevo');
const modal = new bootstrap.Modal(document.getElementById('modal'));
const $ = (id) => document.getElementById(id);

// Para saber si el usuario actual es admin o administrativo
const isAdmin = window.CURRENT_USER_ROLE === 'admin';
const isAdministrativo = window.CURRENT_USER_ROLE === 'administrativo';

/* =========================================
   HELPERS
   ========================================= */
function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  const bg = type === 'success' ? 'bg-success' : type === 'error' ? 'bg-danger' : 'bg-info';
  const el = document.createElement('div');
  el.className = `toast align-items-center text-white ${bg} border-0`;
  el.role = 'alert'; el.ariaLive = 'assertive'; el.ariaAtomic = 'true';
  el.innerHTML = `<div class="d-flex"><div class="toast-body">${message}</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>`;
  container.appendChild(el);
  const t = new bootstrap.Toast(el, { delay: 2800 }); t.show();
  el.addEventListener('hidden.bs.toast', () => el.remove());
}

async function fetchJSON(url, opts) {
  const r = await fetch(url, opts);
  const text = await r.text();
  if (!r.ok) {
    try {
      const j = JSON.parse(text);
      throw new Error(j?.error || j?.errors?.join(' | ') || text || 'Error');
    } catch {
      throw new Error(text || 'Error');
    }
  }
  return text ? JSON.parse(text) : {};
}

/* =========================================
   CARGAR SELECT DE CARGOS (PARA EL MODAL)
   ========================================= */
async function cargarCargos() {
  const select = $('cargoId');
  select.innerHTML = `<option value="">(Sin cargo)</option>`;
  const cargos = await fetchJSON(API_CARGOS);
  cargos.forEach(c => {
    const opt = document.createElement('option');
    opt.value = c.id;
    opt.textContent = `${c.nombre} (${c.tipo})`;
    select.appendChild(opt);
  });
}

/* =========================================
   LISTAR PERSONAS (FILTRADO EN FRONTEND)
   ========================================= */
async function listar() {
  // 1. Obtenemos SIEMPRE todos los datos de la API
  // (Quitamos los params del fetch para traer todo y filtrar aquí)
  let data = await fetchJSON(API); 
  
  tbody.innerHTML = '';

  // Verificamos si hay datos antes de filtrar
  if (!Array.isArray(data)) data = [];

  // 2. Recogemos los valores de los inputs del HTML (convertimos a minúsculas para comparar)
  const fId = $('fIdentificacion')?.value?.trim().toLowerCase();
  const fNom = $('fNombres')?.value?.trim().toLowerCase();
  const fApe = $('fApellidos')?.value?.trim().toLowerCase();
  const fCar = $('fCargo')?.value?.trim().toLowerCase();
  const fEma = $('fEmail')?.value?.trim().toLowerCase();
  const fTel = $('fTelefono')?.value?.trim().toLowerCase();

  // 3. Aplicamos el filtrado en memoria
  const filteredData = data.filter(p => {
    // Validamos cada campo. Si el filtro tiene texto, verificamos si coincide.
    // Usamos (p.campo || '') para evitar errores si el dato viene null
    const matchId  = !fId  || (p.identificacion || '').toLowerCase().includes(fId);
    const matchNom = !fNom || (p.nombres || '').toLowerCase().includes(fNom);
    const matchApe = !fApe || (p.apellidos || '').toLowerCase().includes(fApe);
    // Para cargo, buscamos en el objeto anidado (p.Cargo.nombre) o en un string plano si viene así
    const cargoNombre = p.Cargo?.nombre || p.cargo || ''; 
    const matchCar = !fCar || cargoNombre.toLowerCase().includes(fCar);
    const matchEma = !fEma || (p.email || '').toLowerCase().includes(fEma);
    const matchTel = !fTel || (p.telefono || '').toLowerCase().includes(fTel);

    // La fila pasa si cumple TODAS las condiciones
    return matchId && matchNom && matchApe && matchCar && matchEma && matchTel;
  });

  // 4. Verificamos si tras el filtro quedó algo
  if (!filteredData.length) {
    tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted py-4">Sin resultados que coincidan con la búsqueda</td></tr>';
    return;
  }

  // 5. Renderizamos los datos ya filtrados
  filteredData.forEach(p => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${p.id}</td>
      <td>${p.identificacion || ''}</td>
      <td>${p.nombres || ''}</td>
      <td>${p.apellidos || ''}</td>
      <td>${p.Cargo?.nombre || ''}</td>
      <td>${p.email || ''}</td>
      <td>${p.telefono || ''}</td>
      <td>${p.createdAt || ''}</td>
      <td>${p.updatedAt || ''}</td>
      <td>
        ${
          (isAdmin || isAdministrativo)
            ? `
              <button class="btn btn-sm btn-warning me-2"
                      data-act="edit" data-id="${p.id}">Editar</button>
              <button class="btn btn-sm btn-danger"
                      data-act="del" data-id="${p.id}">Eliminar</button>
            `
            : `<span class="text-muted small">Solo lectura</span>`
        }
      </td>`;
    tbody.appendChild(tr);
  });
}

/* =========================================
   EVENTOS DE FILTRADO
   ========================================= */

// Botón Filtrar
document.getElementById('btnFiltrar')?.addEventListener('click', () => {
    listar().catch((e) => showToast(e.message || 'Error al filtrar', 'error'));
});

// Botón Limpiar
document.getElementById('btnLimpiar')?.addEventListener('click', () => {
    // Array con los IDs de tus inputs de filtro
    const filtros = ['fIdentificacion', 'fNombres', 'fApellidos', 'fCargo', 'fEmail', 'fTelefono'];
    
    filtros.forEach(id => {
        const input = $(id);
        if (input) input.value = '';
    });

    // Recargar la tabla sin filtros
    listar().catch((e) => showToast(e.message || 'Error al limpiar', 'error'));
});


/* =========================================
   NUEVA PERSONA (MODAL)
   ========================================= */
btnNuevo?.addEventListener('click', async () => {
  $('title').textContent = 'Nueva persona de mantenimiento';
  $('id').value = '';
  $('identificacion').value = '';
  $('nombres').value = '';
  $('apellidos').value = '';
  $('email').value = '';
  $('telefono').value = '';
  
  await cargarCargos();
  $('cargoId').value = '';
  
  modal.show();
});

/* =========================================
   ACCIONES EDITAR / ELIMINAR
   ========================================= */
tbody.addEventListener('click', async (e) => {
  if (!(isAdmin || isAdministrativo)) return;

  const btn = e.target.closest('button'); if (!btn) return;
  const { act, id } = btn.dataset;

  if (act === 'edit') {
    try {
        const it = await fetchJSON(`${API}/${id}`);
        $('title').textContent = `Editar persona #${id}`;
        $('id').value = id;
        $('identificacion').value = it.identificacion || '';
        $('nombres').value = it.nombres || '';
        $('apellidos').value = it.apellidos || '';
        $('email').value = it.email || '';
        $('telefono').value = it.telefono || '';
        
        await cargarCargos();
        // Maneja si el objeto cargo viene como cargoId plano o objeto Cargo anidado
        $('cargoId').value = (it.cargoId ?? it.Cargo?.id) || '';
        
        modal.show();
    } catch(err) {
        showToast('Error al cargar datos para edición', 'error');
    }

  } else if (act === 'del') {
    if (!confirm('¿Eliminar persona?')) return;
    try {
      await fetchJSON(`${API}/${id}`, { method: 'DELETE' });
      await listar();
      showToast('Persona eliminada', 'info');
    } catch (e) {
      showToast(e.message || 'No se pudo eliminar', 'error');
    }
  }
});

/* =========================================
   GUARDAR (POST/PUT)
   ========================================= */
document.getElementById('form').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!(isAdmin || isAdministrativo)) {
    showToast('No tiene permisos para modificar responsables/custodios', 'error');
    return;
  }
  
  const payload = {
    identificacion: $('identificacion').value.trim(),
    nombres: $('nombres').value.trim(),
    apellidos: $('apellidos').value.trim(),
    cargoId: $('cargoId').value ? Number($('cargoId').value) : null,
    email: $('email').value.trim() || null,
    telefono: $('telefono').value.trim() || null,
  };
  
  const id = $('id').value;
  
  try {
    if (id) {
      await fetchJSON(`${API}/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    } else {
      await fetchJSON(API, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    }
    modal.hide();
    await listar();
    showToast(id ? 'Persona actualizada' : 'Persona creada');
  } catch (e) {
    showToast(e.message || 'Error al guardar', 'error');
  }
});

/* =========================================
   INIT
   ========================================= */
(async function init() {
  try {
    await listar();
  } catch (e) {
    console.error(e);
    showToast('Error al listar', 'error');
  }
})();